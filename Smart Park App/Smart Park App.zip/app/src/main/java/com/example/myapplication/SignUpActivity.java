package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

@SuppressLint("NewApi")
public class SignUpActivity extends Activity {

    EditText txtUsername, txtPassword,txtPlateNumber,txtCreditCard ;
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 64)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        initialize();
    }

    private void initialize()
    {
        txtUsername = (EditText)findViewById(R.id.txtUsername);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        txtPlateNumber = (EditText)findViewById(R.id.txtPlateNumber);
        txtCreditCard = (EditText)findViewById(R.id.txtCreditCard);
    }

    public void gotoTentant(View view) throws NoSuchAlgorithmException {
        String  username, password , platenumber,creditcard;

        username = txtUsername.getText().toString();
        password = txtPassword.getText().toString();
        platenumber = txtPlateNumber.getText().toString();
        creditcard = txtCreditCard.getText().toString();
        String HashPassword = toHexString(getSHA(password));
        String HashCreditCard = toHexString(getSHA(creditcard));
        String lastFourDigits = "";
        if (creditcard.length() >= 4)
            lastFourDigits = creditcard.substring(creditcard.length() - 4 );
        if (username != null && !username.trim().isEmpty() && password != null &&
                !password.trim().isEmpty()  && platenumber.length() == 7 && creditcard.length() >= 8) {
            String add_url = "http://addnewuser.azurewebsites.net/api/adduser?username=" + username + "&password=" + HashPassword + "&acctype=tenant&platenumber=" + platenumber + "&creditcard=" + HashCreditCard+"&cclast4=" + lastFourDigits;
            OkHttpClient client2 = new OkHttpClient();
            Request request2 = new Request.Builder()
                    .url(add_url)
                    .build();
            client2.newCall(request2).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    String mMessage = response.body().string();
                    JSONObject resBody = null;
                    try {
                        resBody = new JSONObject(mMessage);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String restype = null;
                    try {
                        restype = resBody.getString("res");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (restype.equals("ok")) {
                        SignUpActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "User Added Successfully", Toast.LENGTH_LONG).show();
                            }
                        });
                        Intent hh = new Intent(SignUpActivity.this, MainActivity.class);
                        startActivity(hh);
                    } else {
                        if (restype.equals("userExists")) {
                            SignUpActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "User Exists", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                        else {
                            SignUpActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "InternalError", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }
                }
            });
        }
        else
        {
            Toast.makeText(SignUpActivity.this, "Empty or incorrect name/user or password or platenumber!", Toast.LENGTH_SHORT).show();
        }
    }
    public void gotoOwner(View view) throws NoSuchAlgorithmException
    {
        String username, password,platenumber,bankaccountnumber;

        username = txtUsername.getText().toString();
        password = txtPassword.getText().toString();
        platenumber = txtPlateNumber.getText().toString();
        bankaccountnumber = txtCreditCard.getText().toString();
        String HashPassword = toHexString(getSHA(password));
        String HashBankAccountNumber = toHexString(getSHA(bankaccountnumber));
        String lastFourDigits = "";
        if (bankaccountnumber.length() >= 4)
            lastFourDigits = bankaccountnumber.substring(bankaccountnumber.length() - 4 );

        if (username != null && !username.trim().isEmpty() && password != null &&
                !password.trim().isEmpty() && platenumber.length() == 7 && bankaccountnumber.length() >= 6) {
            String add_url = "http://addnewuser.azurewebsites.net/api/adduser?username="+username+"&password="+HashPassword+"&acctype=owner&platenumber="+platenumber+"&creditcard="+HashBankAccountNumber+"&cclast4=" + lastFourDigits  ;
            OkHttpClient client2 = new OkHttpClient();
            Request request2 = new Request.Builder()
                    .url(add_url)
                    .build();
            client2.newCall(request2).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    String mMessage = response.body().string();
                    JSONObject resBody = null;
                    try {

                        resBody = new JSONObject(mMessage);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String restype = null;
                    try {
                        restype = resBody.getString("res");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (restype.equals("ok")){
                        SignUpActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "User Added Successfully", Toast.LENGTH_LONG).show();
                            }
                        });
                        Intent hh = new Intent(SignUpActivity.this, MainActivity.class);
                        startActivity(hh);
                    }
                    else {
                        if (restype.equals("userExists")) {
                            SignUpActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "User Exists", Toast.LENGTH_LONG).show();
                                }
                            });
                        }else {
                            SignUpActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "InternalError", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }

                }
            });
        }

        else
        {
            Toast.makeText(SignUpActivity.this, "Empty or incorrect name/user or password or platenumber! or creditcard", Toast.LENGTH_SHORT).show();
        }
    }
}