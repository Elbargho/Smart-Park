package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChangePasswordActivity extends AppCompatActivity {
    EditText input_password;
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 64)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        input_password = (EditText) findViewById(R.id.NewPasswordTxt);
    }
    public void ChangePassword(View View){
        String NewPassword = input_password.getText().toString();
        String HashNewPassword = null;
        try {
            HashNewPassword = toHexString(getSHA(NewPassword));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        String CreditCard = (getIntent().getStringExtra("CREDICARD"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
        String add_url = "https://updateuserdetails.azurewebsites.net/api/updateUser?username="+UserName+"&oldpassword="+Password+"&newpassword="+HashNewPassword+"&platenumber="+PlateNumber+"&creditcard="+CreditCard+"&cclast4=" + Cclast4  ;
        OkHttpClient client2 = new OkHttpClient();
        Request request2 = new Request.Builder()
                .url(add_url)
                .build();
        String finalHashNewPassword = HashNewPassword;
        client2.newCall(request2).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String mMessage = response.body().string();
                JSONObject resBody = null;
                try {

                    resBody = new JSONObject(mMessage);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String restype = null;
                try {
                    restype = resBody.getString("res");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (restype.equals("ok")) {
                    ChangePasswordActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Change Password Successfully", Toast.LENGTH_LONG).show();
                            String AccType = (getIntent().getStringExtra("AccType"));
                            Intent intent;
                            if(AccType.equals("Owner"))
                                intent = new Intent(ChangePasswordActivity.this, OwnerProfileActivity.class);
                            else
                                intent = new Intent(ChangePasswordActivity.this, TenantProfileActivity.class);
                            intent.putExtra("CCLAST4", Cclast4);
                            intent.putExtra("USERNAME", UserName);
                            intent.putExtra("CREDICARD",CreditCard);
                            intent.putExtra("PASSWORD", finalHashNewPassword);
                            intent.putExtra("PLATENUMBER",PlateNumber);
                            startActivity(intent);
                        }
                    });
                } else {
                    ChangePasswordActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "error Doesn't Change Password", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }
}