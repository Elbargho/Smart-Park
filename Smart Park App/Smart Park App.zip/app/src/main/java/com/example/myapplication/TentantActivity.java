package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.microsoft.signalr.HubConnection;
import com.microsoft.signalr.HubConnectionBuilder;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import io.reactivex.Single;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TentantActivity extends AppCompatActivity {
    EditText input_current_payment;
    Handler handler = new Handler();
    static HubConnection hub;
    static HubConnection hub1;
    Runnable runnable;
    int delay = 10000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentant);
        input_current_payment = (EditText) findViewById(R.id.editTextNumber);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        final String[] AccessKey = new String[1];
        final String[] SignalrURL = new String[1];

        JSONObject json = new JSONObject();
        try {
            json.put("UserId", UserName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String jsonStr = json.toString();
        MediaType MEDIA_TYPE = MediaType.parse("application/json");
        String URL = "https://reservepark.azurewebsites.net/api/negotiate?";
        OkHttpClient Client = new OkHttpClient();
        RequestBody Body = RequestBody.create(MEDIA_TYPE, jsonStr);
        Request request = new Request.Builder()
                .url(URL)
                .post(Body)
                .header("Content-Type", "application/json")
                .build();
        Client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                String mMessage = e.getMessage().toString();
                Log.w("failure Response", mMessage);
                //call.cancel();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("blaaaaaaa");
                String mMessage = response.body().string();
                TentantActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject jsonObj = null;
                        try {
                            jsonObj = new JSONObject(mMessage);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            SignalrURL[0] = jsonObj.getString("url");
                            System.out.println(SignalrURL[0]);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            AccessKey[0] = jsonObj.getString("accessToken");
                            System.out.println(AccessKey[0]);
                            System.out.println("shadi");
                            hub = HubConnectionBuilder.create(SignalrURL[0]).withAccessTokenProvider(Single.defer(() -> {
                                        return Single.just(AccessKey[0]);

                                    }))
                                    .build();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        hub.start();
                        hub.on("ReleaseNotify", (payment, tenant, owner
                        ) -> {
                            TentantActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    System.out.println(tenant);
                                    System.out.println(owner);
                                    System.out.println(UserName);
                                    if (tenant.equals(UserName)) {
                                        Toast.makeText(getApplicationContext(), "you left the park , payment is " + payment, Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }, String.class, String.class, String.class);
                        hub.on("NotificationToUser", (user, message
                        ) -> {
                            TentantActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (user.equals(UserName)) {
                                        Toast.makeText(getApplicationContext(), message , Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }, String.class, String.class);

                    }
                });
            }
        });

    }


    @Override
    protected void onResume() {
        handler.postDelayed(runnable = new Runnable() {
            public void run() {
                handler.postDelayed(runnable, delay);
                String UserName = (getIntent().getStringExtra("USERNAME"));
                String add_url = "https://getcurrentpayment.azurewebsites.net/api/getCurrentPayment?username=" + UserName;
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(add_url)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        String mMessage = e.getMessage().toString();
                        Log.w("failure Response", mMessage);
                        //call.cancel();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                        String mMessage = response.body().string();
                        System.out.println(mMessage);
                        JSONObject resBody = null;
                        try {

                            resBody = new JSONObject(mMessage);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            String res = resBody.getString("res");
                            if (res.equals("ok")) {
                                String currentPayment = resBody.getString("currentPayment");
                                input_current_payment.setText(currentPayment);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }, delay);
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable); //stop handler when activity not visible super.onPause();
    }
    public void gotoAvailableParks(View View){
        Intent intent = new Intent(TentantActivity.this, ShowAvailableParkingActivity.class);
        //send username to showavailable activity
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        intent.putExtra("USERNAME", UserName);
        intent.putExtra("PASSWORD", Password);
        startActivity(intent);

    }

    public void gotoMyProfile(View View){
        Intent intent = new Intent(TentantActivity.this, TenantProfileActivity.class);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
        String CreditCard = (getIntent().getStringExtra("CREDICARD"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        System.out.println(UserName);
        intent.putExtra("USERNAME", UserName);
        intent.putExtra("PLATENUMBER",PlateNumber);
        intent.putExtra("CREDICARD", CreditCard);
        intent.putExtra("CCLAST4",Cclast4);
        intent.putExtra("PASSWORD", Password);
        startActivity(intent);
    }

}