package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;

import android.os.Bundle;
import android.view.View;
import com.microsoft.signalr.Action1;
import com.microsoft.signalr.HubConnection;
import com.microsoft.signalr.HubConnectionBuilder;
import com.microsoft.signalr.HubConnectionState;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import okhttp3.Call;
import okhttp3.Callback;
import java.io.IOException;
import java.util.concurrent.locks.ReentrantLock;

import io.reactivex.Single;
import android.util.Log;

import android.app.Notification;
import android.widget.EditText;
import android.widget.Toast;

public class OwnerActivity extends AppCompatActivity {
    NotificationManagerCompat notificationManager;
    static HubConnection hub;
    EditText input_budget;
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(hub.getConnectionState().equals(HubConnectionState.CONNECTED)){
            hub.stop();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner);
        input_budget = (EditText) findViewById(R.id.editTextNumber);
        notificationManager = NotificationManagerCompat.from(this);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        final String[] AccessKey = new String[1];
        final String[] SignalrURL = new String[1];

        JSONObject json = new JSONObject();
        try {
            json.put("UserId", UserName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String jsonStr = json.toString();
        MediaType MEDIA_TYPE = MediaType.parse("application/json");
        String URL = "https://reservepark.azurewebsites.net/api/negotiate?";
        OkHttpClient Client = new OkHttpClient();
        RequestBody Body = RequestBody.create(MEDIA_TYPE, jsonStr);
        Request request = new Request.Builder()
                .url(URL)
                .post(Body)
                .header("Content-Type", "application/json")
                .build();
        Client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                String mMessage = e.getMessage().toString();
                Log.w("failure Response", mMessage);
                //call.cancel();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("blaaaaaaa");
                String mMessage = response.body().string();
                OwnerActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject jsonObj = null;
                        try {
                            jsonObj = new JSONObject(mMessage);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            SignalrURL[0] = jsonObj.getString("url");
                            System.out.println(SignalrURL[0]);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            AccessKey[0] = jsonObj.getString("accessToken");
                            System.out.println(AccessKey[0]);
                            System.out.println("shadi");
                            hub = HubConnectionBuilder.create(SignalrURL[0]).withAccessTokenProvider(Single.defer(() -> {
                                        return Single.just(AccessKey[0]);

                                    }))
                                    .build();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        hub.start();
                        hub.on("ReserveNotify", (tenant,owner
                        ) -> {
                            OwnerActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    System.out.println(tenant);
                                    System.out.println(tenant);
                                    System.out.println(owner);
                                    System.out.println(UserName);
                                    if(owner.equals(UserName)) {

                                        Toast.makeText(getApplicationContext(), tenant + " make reserve", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }, String.class,String.class);
                        hub.on("ReleaseNotify", (payment,tenant,owner
                        ) -> {
                            OwnerActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    System.out.println(tenant);
                                    System.out.println(owner);
                                    System.out.println(UserName);
                                    if(owner.equals(UserName)) {
                                        input_budget.setText(payment);
                                        Toast.makeText(getApplicationContext(), tenant + " left the park , budget is " + payment, Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }, String.class,String.class,String.class);
                        hub.on("NotificationToUser", (user, message
                        ) -> {
                            OwnerActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (user.equals(UserName)) {
                                        Toast.makeText(getApplicationContext(), message , Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }, String.class, String.class);

                    }
            });

        }
        });
    }

            public void gotoAddPark(View view) {
                String UserName = (getIntent().getStringExtra("USERNAME"));
                Intent i = new Intent(OwnerActivity.this, AddParkingActivity.class);
                i.putExtra("USERNAME", UserName);
                String Password = (getIntent().getStringExtra("PASSWORD"));
                i.putExtra("PASSWORD", Password);
                startActivity(i);
            }
            public void gotoRemovePark(View view) {
                String UserName = (getIntent().getStringExtra("USERNAME"));
                String Password = (getIntent().getStringExtra("PASSWORD"));
                String add_url = "https://removepark.azurewebsites.net/api/removePark?username="+UserName+"&password="+Password;
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(add_url)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        String mMessage = e.getMessage().toString();
                        Log.w("failure Response", mMessage);
                        //call.cancel();
                    }
                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        String mMessage = response.body().string();
                        System.out.println(mMessage);
                        JSONObject resBody = null;
                        try {

                            resBody = new JSONObject(mMessage);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            String res = resBody.getString("res");
                            String state = resBody.getString("state");
                            if (res.equals("ok")) {
                                OwnerActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), state , Toast.LENGTH_LONG).show();
                                    }
                                });
                            } else {
                                OwnerActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), "internal error", Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });

            }
            public void gotoProfile(View view){
                String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
                String CreditCard = (getIntent().getStringExtra("CREDICARD"));
                String UserName = (getIntent().getStringExtra("USERNAME"));
                String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
                String Password = (getIntent().getStringExtra("PASSWORD"));
                Intent j = new Intent(OwnerActivity.this, OwnerProfileActivity.class);
                j.putExtra("USERNAME", UserName);
                j.putExtra("PLATENUMBER", PlateNumber);
                j.putExtra("CREDICARD",CreditCard );
                j.putExtra("CCLAST4",Cclast4);
                j.putExtra("PASSWORD", Password);
                startActivity(j);
            }
}