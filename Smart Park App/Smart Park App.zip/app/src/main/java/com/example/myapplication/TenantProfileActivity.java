package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class TenantProfileActivity extends AppCompatActivity {
    EditText input_username,input_creditcard,input_platenumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_profile);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
        input_username = (EditText) findViewById(R.id.PersonName);
        input_creditcard = (EditText) findViewById(R.id.CreditCard);
        input_platenumber = (EditText) findViewById(R.id.PlateNumber);
        input_username.setText(UserName);
        input_platenumber.setText(PlateNumber);
        input_creditcard.setText("************"+Cclast4);
    }
    public void gotoUpdateCreditCard(View View){
        Intent intent = new Intent(TenantProfileActivity.this, ChangeCreditCardActivity.class);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        intent.putExtra("USERNAME", UserName);
        intent.putExtra("PLATENUMBER",PlateNumber);
        intent.putExtra("PASSWORD", Password);
        startActivity(intent);

    }
    public void gotoUpdatePlateNumber(View View){
        Intent intent = new Intent(TenantProfileActivity.this, ChangePlateNumberActivity.class);
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String CreditCard = (getIntent().getStringExtra("CREDICARD"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
        intent.putExtra("USERNAME", UserName);
        intent.putExtra("CREDICARD",CreditCard);
        intent.putExtra("PASSWORD", Password);
        intent.putExtra("CCLAST4", Cclast4);
        intent.putExtra("AccType","Tenant");
        startActivity(intent);

    }
    public void gotoUpdatePassword(View View){
        Intent intent = new Intent(TenantProfileActivity.this, ChangePasswordActivity.class);
        String PlateNumber = (getIntent().getStringExtra("PLATENUMBER"));
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String CreditCard = (getIntent().getStringExtra("CREDICARD"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));

        intent.putExtra("USERNAME", UserName);
        intent.putExtra("CREDICARD",CreditCard);
        intent.putExtra("PASSWORD", Password);
        intent.putExtra("CCLAST4", Cclast4);
        intent.putExtra("PLATENUMBER",PlateNumber);
        intent.putExtra("AccType","Tenant");
        startActivity(intent);

    }
}