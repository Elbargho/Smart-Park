package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.microsoft.signalr.Action1;
import com.microsoft.signalr.HubConnection;
import com.microsoft.signalr.HubConnectionBuilder;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;

import io.reactivex.Single;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
public class ShowAvailableParkingActivity extends AppCompatActivity {
    static ArrayList<String> Requests = new ArrayList<String>();
    static ArrayList<String> Users_Requesting = new ArrayList<String>();
    static ArrayList<String> CarPlates_Requesting = new ArrayList<String>();
    static Boolean isEmpty=true;
    static Boolean isHere=false;
    static HubConnection hub1;


    @Override
    public void onBackPressed() {
        getRequests(null,null,true,ShowAvailableParkingActivity.this);
        super.onBackPressed();
        isHere=false;
    }

    EditText input_location,input_price,input_startingtime,input_endingtime;
    ProgressDialog progressDialog;
    static ReentrantLock mutex = new ReentrantLock(true);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_available_parking);
        final ListView ListView1 = (ListView) findViewById(R.id.LstView2);
        input_location = (EditText) findViewById(R.id.txtLocation);
        input_price = (EditText) findViewById(R.id.txtPrice);
        input_startingtime = (EditText) findViewById(R.id.StartingTime);
        input_endingtime = (EditText) findViewById(R.id.EndingTime);
        Button ReserveBtn = (Button) findViewById(R.id.ReserveBtn);

        final ArrayAdapter MyAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Requests);
        isHere = true;
        getRequests(ListView1, MyAdapter1, false, ShowAvailableParkingActivity.this);

        String UserName = (getIntent().getStringExtra("USERNAME"));
        final String[] AccessKey = new String[1];
        final String[] SignalrURL = new String[1];

        JSONObject json = new JSONObject();
        try {
            json.put("UserId", UserName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String jsonStr = json.toString();
        MediaType MEDIA_TYPE = MediaType.parse("application/json");
        String URL = "https://addpark.azurewebsites.net/api/negotiate?";
        OkHttpClient Client = new OkHttpClient();
        RequestBody Body = RequestBody.create(MEDIA_TYPE, jsonStr);
        Request request = new Request.Builder()
                .url(URL)
                .post(Body)
                .header("Content-Type", "application/json")
                .build();
        Client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                String mMessage = e.getMessage().toString();
                Log.w("failure Response", mMessage);
                //call.cancel();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("blaaaaaaa");
                String mMessage = response.body().string();
                ShowAvailableParkingActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject jsonObj = null;
                        try {
                            jsonObj = new JSONObject(mMessage);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            SignalrURL[0] = jsonObj.getString("url");
                            System.out.println(SignalrURL[0]);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        try {
                            AccessKey[0] = jsonObj.getString("accessToken");
                            System.out.println(AccessKey[0]);
                            System.out.println("shadi");
                            hub1 = HubConnectionBuilder.create(SignalrURL[0]).withAccessTokenProvider(Single.defer(() -> {
                                        return Single.just(AccessKey[0]);

                                    }))
                                    .build();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        hub1.start();
                        hub1.on("AddParkNotify", location -> {
                            ShowAvailableParkingActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    System.out.println(location);
                                    getRequests(ListView1, MyAdapter1, false, ShowAvailableParkingActivity.this);
                                    Toast.makeText(getApplicationContext(),  "The Location " + location + " is added to the park table", Toast.LENGTH_LONG).show();
                                }
                            });
                        },String.class);
                    }
                });
            }
        });
        ReserveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String location = input_location.getText().toString();
                final String price = input_price.getText().toString();
                final String starting_time = input_startingtime.getText().toString();
                final String ending_time = input_endingtime.getText().toString();
                String UserName = (getIntent().getStringExtra("USERNAME"));
                String Password = (getIntent().getStringExtra("PASSWORD"));
                String row = "{Location: " + location + " , Price: " + price + " , Starting Time: " + starting_time + " , Ending Time: " + ending_time + " }";
                if (Requests.contains(row)) {
                    System.out.println(UserName);

                    String url = "https://reservepark.azurewebsites.net/api/reservepark?username=" + UserName +"&password=" + Password +"&location=" + location;
                    OkHttpClient client3 = new OkHttpClient();
                    Request request3 = new Request.Builder()
                            .url(url)
                            .build();
                    client3.newCall(request3).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            String mMessage = response.body().string();
                            System.out.println(mMessage);
                            JSONObject resBody = null;
                            try {
                                resBody = new JSONObject(mMessage);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {
                                String res = resBody.getString("res");
                                if (res.equals("ok")) {
                                    ShowAvailableParkingActivity.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                mutex.lock();
                                                Requests.remove(row);
                                                ListView1.setAdapter(MyAdapter1);
                                                runOnUiThread(new Runnable() {
                                                    public void run() {
                                                        final Toast toast = Toast.makeText(getApplicationContext(), "Request Approved Successfully", Toast.LENGTH_LONG);
                                                        toast.show();
                                                    }
                                                });
                                            } finally {
                                                mutex.unlock();
                                            }
                                        }
                                    });
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
        ListView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String) parent.getItemAtPosition(position);
                String[] splitedItem = item.split(" ");
                input_location.setText(splitedItem[1]);
                input_price.setText(splitedItem[4]);
                input_startingtime.setText(splitedItem[8]);
                input_endingtime.setText(splitedItem[splitedItem.length - 2]);
            }
        });

    }
    public void getRequests(ListView listView1, ArrayAdapter myAdapter1, Boolean reutrnIsEmpty, Context context) {

        OkHttpClient client = new OkHttpClient();
        String url = "https://getparkstable.azurewebsites.net/api/parkstable";
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                if (response.isSuccessful()) {
                    final String mMessage = response.body().string();
                    ShowAvailableParkingActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                             mutex.lock();
                            //progressDialog= new ProgressDialog(context);
                            // }
                            //progressDialog.show();
                           // progressDialog.setContentView(R.layout.progress_dialog);
                            //progressDialog.getWindow().setBackgroundDrawableResource(
                                   // android.R.color.transparent
                            //);
                            JSONObject resBody = null;
                            try {

                                resBody = new JSONObject(mMessage);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            JSONArray jsonArr = null;
                            try {
                                jsonArr  = resBody.getJSONArray("Parks Table");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if(reutrnIsEmpty) {
                            if (jsonArr.length() > 0) {
                                isEmpty = false;

                            } else if ( jsonArr.length() == 0) {
                            isEmpty = true;

                            }

                            }
                            if(reutrnIsEmpty){
                                mutex.unlock();
                                return;
                             }
                            Requests.clear();
                            for (int i = 0; i < jsonArr.length(); i++) {
                                JSONObject jsonObj = null;
                                try {
                                    jsonObj = jsonArr.getJSONObject(i);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                System.out.println(jsonObj);
                                String Location = "";
                                try {
                                    Location = jsonObj.getString("Location");
                                    System.out.println(Location);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String Price = "";
                                try {
                                    Price = jsonObj.getString("Price");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String StartingTime= "";
                                try {
                                    StartingTime = jsonObj.getString("Starting Time");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String EndingTime = "";
                                try {
                                    EndingTime = jsonObj.getString("Ending Time");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                String row = "{Location: "+Location+" , Price: " + Price +" , Starting Time: "+StartingTime+" , Ending Time: "+EndingTime+" }";
                                System.out.println(row);
                                Requests.add(row);
                            }
                            listView1.setAdapter(myAdapter1);
                            System.out.println(Requests);
                            mutex.unlock();
                        }
                    });
                }

            }
        });


    }
}