package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChangePlateNumberActivity extends AppCompatActivity {
    EditText input_platenumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_plate_number);
        input_platenumber = (EditText) findViewById(R.id.NewPlateNumber);
    }
    public void ChangePlateNumber(View View){
        String PlateNumber = input_platenumber.getText().toString();
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String CreditCard = (getIntent().getStringExtra("CREDICARD"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        String Cclast4 = (getIntent().getStringExtra("CCLAST4"));
        String add_url = "https://updateuserdetails.azurewebsites.net/api/updateUser?username="+UserName+"&oldpassword="+Password+"&newpassword="+Password+"&platenumber="+PlateNumber+"&creditcard="+CreditCard+"&cclast4=" + Cclast4  ;
        OkHttpClient client2 = new OkHttpClient();
        Request request2 = new Request.Builder()
                .url(add_url)
                .build();
        client2.newCall(request2).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String mMessage = response.body().string();
                JSONObject resBody = null;
                try {

                    resBody = new JSONObject(mMessage);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String restype = null;
                try {
                    restype = resBody.getString("res");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (restype.equals("ok")) {
                    ChangePlateNumberActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Change PlateNumber Successfully", Toast.LENGTH_LONG).show();
                            String AccType = (getIntent().getStringExtra("AccType"));
                            Intent intent;
                            if(AccType.equals("Owner"))
                                intent = new Intent(ChangePlateNumberActivity.this, OwnerProfileActivity.class);
                            else
                                intent = new Intent(ChangePlateNumberActivity.this, TenantProfileActivity.class);
                            intent.putExtra("PLATENUMBER",PlateNumber);
                            intent.putExtra("USERNAME", UserName);
                            intent.putExtra("CREDICARD",CreditCard);
                            intent.putExtra("PASSWORD", Password);
                            intent.putExtra("CCLAST4", Cclast4);
                            startActivity(intent);
                        }
                    });
                } else {
                    ChangePlateNumberActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "error Doesn't Change Plate Number", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }
}