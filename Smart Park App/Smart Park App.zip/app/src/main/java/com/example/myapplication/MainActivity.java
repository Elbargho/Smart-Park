package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    EditText txtUsername, txtPassword;

    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        // Static getInstance method is called with hashing SHA
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        // Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hash);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 64)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
    }

    public void gotoPanel(View view) throws NoSuchAlgorithmException {
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();

        if (username != null && !username.trim().isEmpty() && password != null && !password.trim().isEmpty()) {
            String HashPassword = toHexString(getSHA(password));
            String add_url = "https://usersignin.azurewebsites.net/api/login?username=" + username + "&password=" + HashPassword ;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(add_url)
                    .build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    String mMessage = e.getMessage().toString();
                    Log.w("failure Response", mMessage);
                    //call.cancel();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                    String mMessage = response.body().string();
                    System.out.println(mMessage);
                    JSONObject resBody = null;
                    try {

                        resBody = new JSONObject(mMessage);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        String res = resBody.getString("res");
                        if (res.equals("ok")){
                            JSONObject accDetails = resBody.getJSONObject("accDetails");
                            String acctype = accDetails.getString("AccountType");
                            if(acctype.equals("tenant")){
                                String creditcard = accDetails.getString("CreditCard");
                                String cclast4 = accDetails.getString("cclast4");
                                String platenumber = accDetails.getString("platenumber");
                                Intent intent = new Intent(MainActivity.this, TentantActivity.class);
                                intent.putExtra("CREDICARD",creditcard);
                                intent.putExtra("PLATENUMBER",platenumber);
                                intent.putExtra("USERNAME", username); // to pass the username to another layout
                                intent.putExtra("PASSWORD", HashPassword);
                                intent.putExtra("CCLAST4", cclast4);
                                startActivity(intent);
                            }
                            else{
                                String bankaccountnumber = accDetails.getString("CreditCard");
                                String platenumber = accDetails.getString("platenumber");
                                String cclast4 = accDetails.getString("cclast4");
                                Intent intent = new Intent(MainActivity.this, OwnerActivity.class);
                                intent.putExtra("USERNAME", username); // to pass the username to another layout
                                intent.putExtra("PASSWORD", HashPassword);
                                intent.putExtra("CREDICARD",bankaccountnumber);
                                intent.putExtra("PLATENUMBER",platenumber);
                                intent.putExtra("CCLAST4", cclast4);
                                startActivity(intent);
                            }
                        }else {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    //final Toast toast = Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG);
                                    //toast.show();
                                    Toast.makeText(MainActivity.this, "Empty or incorrect user or password!", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
        }
    }
    public void gotoSignup(View view)
    {
        Intent a = new Intent(this, SignUpActivity.class);
        startActivity(a);

    }

}