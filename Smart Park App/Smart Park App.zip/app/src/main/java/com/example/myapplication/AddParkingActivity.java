package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AddParkingActivity extends AppCompatActivity {
    EditText txtLocation,txtPrice,txtStartingTime,txtEndingTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parking);
        initialize();
    }

    private void initialize() {
        txtLocation = (EditText)findViewById(R.id.txtLocation);
        txtPrice = (EditText)findViewById(R.id.txtPrice);
        txtStartingTime = (EditText) findViewById(R.id.StartingTime);
        txtEndingTime = (EditText) findViewById(R.id.EndingTime);
    }
    public void addpark(View view) {
        String UserName = (getIntent().getStringExtra("USERNAME"));
        String Password = (getIntent().getStringExtra("PASSWORD"));
        String Location = txtLocation.getText().toString();
        String Price = txtPrice.getText().toString();
        String StartingTime = txtStartingTime.getText().toString();
        String EndingTime = txtEndingTime.getText().toString();

        if (!Price.trim().isEmpty() && !Location.trim().isEmpty() && !StartingTime.trim().isEmpty() && !EndingTime.trim().isEmpty()){
            String add_url = "https://addpark.azurewebsites.net/api/addpark?username="+UserName+"&password="+Password+ "&location="+Location+"&price="+Price+"&start="+StartingTime+"&end="+EndingTime;
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(add_url)
                    .build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    String mMessage = e.getMessage().toString();
                    Log.w("failure Response", mMessage);
                    //call.cancel();
                }
                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    String mMessage = response.body().string();
                    System.out.println(mMessage);
                    JSONObject resBody = null;
                    try {

                        resBody = new JSONObject(mMessage);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        String res = resBody.getString("res");
                        if (res.equals("ok")) {
                            AddParkingActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "park added successfully", Toast.LENGTH_LONG).show();
                                }
                            });
                        } else {
                            AddParkingActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "InternalError", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }else {
            AddParkingActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), "Empty or Incorrect Location or Price or Time", Toast.LENGTH_LONG).show();
                }
            });
        }

    }
}